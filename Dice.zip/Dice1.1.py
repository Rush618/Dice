# Imports 'random' module
import random

# Defines the 'Minimum' and 'Maximum' variables
min = 1
max = 10

# Defines the 'pause' and 'roll_again' variables
pause = "no"
roll_again = "nothing"

# A welcome message/starting screen
print("")
print("Welcome to the game!")
roll_again = input("Are you ready to start? (y/n): ")

# First level starts if the 'if' statement is true
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    
    # Defines the values for 'Computer' and 'Human' as random integers between the given parameters
    Computer = random.randint(min,max-6)
    Human = random.randint(min+6,max)
    
    # 'Fight scene' message
    print("")
    print("You roll the dice at eachother...")
    print("...and the values are...")
    print("")

    # Accounting for a tie, defaulting to the Human
    if Human - Computer == 0: 
        Human += 1
        pass
    else:

        # Fight output on screen
        print("Computer: %d" % Computer)
        print("Human: %d" % Human)
        print("")

    # Winning/losing condition check
    if Human > Computer:
        print("You've deleted system 32!")
        print("")
        roll_again = input("Move on to the next level? (y/n): ")
        print("")
    elif Human < Computer:
        print("You lose.")
        exit
    else:
        pass    
else:
    pass

if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    
    # Defines the values for 'Computer' and 'Human' as random integers between the given parameters
    Computer2 = random.randint(min,max-4)
    Human = random.randint(min+4,max)
    
    # 'Fight scene' message
    print("")
    print("You roll the dice at eachother...")
    print("...and the values are...")
    print("")

    # Accounting for a tie, defaulting to the Human
    if Human - Computer2 == 0: 
        Human += 1
        pass
    else:

        # Fight output on screen
        print("Computer 2.0: %d" % Computer2)
        print("Human: %d" % Human)
        print("")

    # Winning/losing condition check
    if Human > Computer2:
        print("You've smashed the computer to bits!")
        print("")
        roll_again = input("Move on to the next level? (y/n): ")
        print("")
    elif Human < Computer2:
        print("You lose.")
        exit
    else:
        pass    
else:
    pass