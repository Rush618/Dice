import random

# Integer definitions
user_val = 1
opp_val = 0
max_bonus = 0
min_bonus = 0
i_var = 0
win_val = 0

loot_ints = 0
if loot_ints == 0:
    # Item Rarities
    common = 10
    uncommon = 25
    rare = 50
    mythic = 75
    unique = 90

    loot_bonus = 0
    item_roll = 0
    polish_val = 0

    gem_val = 0
    sapphire_val = 5
    emerald_val = 10
    ruby_val = 15
    diamond_val = 20
else:    pass
loot_strings = "y"
if loot_strings == "y":
    polish_str = "polish"
    gem_name = ""
    sapphire = "sapphire"
    emerald = "emerald"
    ruby = "ruby"
    diamond = "diamond"
else:    pass

dice_perameters = 0
if dice_perameters == 0:
    user_die = 0
    opp_die = 0
    base_max = 6
    base_min = 3

    player_max = base_max
    player_min = base_min

    goblin_max = base_max-2
    goblin_min = base_min-2

    minotaur_max = base_max
    minotaur_min = base_min

    gargoyle_max = base_max*2 - 1
    gargoyle_min = base_min*2 - 1

    werewolf_max = base_max*3 + 2
    werewolf_min = base_min*3 + 1
else:    pass
story_strings = "y"
if story_strings == "y":
    roll_again = "y"
    user_name = "username"
    opp_name = "oppoonent"
    story = "intro"
    s_var = "nothing"
    goblin = "n"
    minotaur = "n"
    gargoyle = "n"
    werewolf = "n"
    castle = "n"
else:    pass

# String definitions
material = "wood"
adj = "rough"
die = "die"
die_type = adj + " " + material + " " + die

def losscon(user,userval,opponent,oppval):
    if userval < oppval:   
        print("")    
        print("%s, you've been defeated by %s." % (user,opponent))
        print("You lose.")
        print("")
        exit()
    else:
        pass

def fight(user,userval,opponent,oppval):
    # 'Fight scene' message
    print("")
    print("You roll the dice at eachother...")
    print("...and the values are...")
    print("")
    # Accounting for a tie, defaulting to opponent1
    if userval - oppval == 0: 
        userval += 1
    else:
        userval = userval
        pass
    # Fight output on screen
    print("%s: %d" % (user,userval))
    print("%s: %d" % (opponent,oppval))
    print("")    

if story == "intro":
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("You wake up alone in the middle of a vast forest with a full moon overhead...")
    print("")
    user_name = input("...as you regain conciousness, you try to remember your name: ")
    print("")
    print("You reach your hand in your pocket and find a %s." % die_type)
    print("")
    print("Stats:")
    print("       Max: %d" % player_max)
    print("       Min: %d" % player_min)
    print("")
    roll_again = input("Press (enter) to start your journey, %s. " % user_name)
    print("")
else:    pass

print("While roaming through the forest, you notice a figure emerge from behind a tree.")
print("As you aproach the figure, you realize that it's a goblin!")
story = input("Fight, or run? (f/r): ")
print("")
roll_again = "y"
if story == "r": # make it so that theres a chance the goblin catches you!!!!!
    roll_again = "n"
else:    pass

# Battle 1: Goblin
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    
    user_die = random.randint(player_min,player_max)
    opp_die = random.randint(goblin_min,goblin_max)

    user_val = user_die
    opp_name = "Goblin"
    opp_val = opp_die
    
    fight(user_name,user_val,opp_name,opp_val)

    if user_val >= opp_val:
        print("You've smashed the goblin to bits!")
        roll_again = input("(enter)")
        print("")
        win_val = 1
        goblin = "y"
    else:
        opp_name = "a goblin"
        losscon(user_name,user_val,opp_name,opp_val)
        pass
else:    pass
roll_again = "n"

# Goblin Reward
if win_val == 1:
    item_roll = random.randint(1,100)
    if item_roll > common:
        print("You notice a small vial next to your fallen opponent.")
        print("It's a Vial of Polish!")
        polish_str = input("Use, or discard the polish? (u/d): ")
        print("")
        if polish_str == "u":
            polish_val = 4
            die_type = "Polished Wood Die"
            print("")
            print("You are now using a %s!" % die_type)
            print("")
            max_bonus += polish_val
            min_bonus += 0
            player_max = base_max
            player_max += max_bonus
            player_min = base_min
            player_min += min_bonus
            print("")
            print("Stats:")
            print("       Max: %d" % player_max)
            print("       Min: %d" % player_min)
            print("")
            print("With great power, comes great responsibility.")
            print("")
            roll_again = input("(enter)")
            print("")
        else:
            print("You drop the vial and it shatters on a rock...")
            print("")
            pass
    else:
        pass    
else:    pass

# Storyline stuff
print("After the excitement with the goblin, you decide to rest and regain your strength.")
story = input("Once your heart finally calms down, you continue your journey. (enter)")
print("")
print("You walk for an hour or so and find a lightly trodden dirt path.")
story = input("Do you follow it? (y/n): ")
print("")
if story == "y":
    print("You follow the path as it winds through the trees; ahead you begin to see a clearing.")
    print("As you draw nearer to the clearing, the moonlight hits your face and you make out what appears to be a wall of large hedges.")
    roll_again = input("(Enter)")
    print("After walking along the wall, you find an entrance to a maze!")
    s_var = input("Would you like to make an attempt at solving the maze? (y/n): ")
    print("")
    if s_var == "y":
        i_var = random.randint(1,100)
        if goblin == "n":
            i_var += 20
        else:
            pass
        if i_var > uncommon:
            roll_again = "y"
            print("While walking through the maze, you notice a faint light being emitted around the corner.")
            print("You slowly aproach the corner, preparing yourserlf for whatever awaits you.")
            s_var = input("(enter)")
        else:
            print("You walk around the maze for a while, but end up at a different entrance.")
            print("Feeling a little defeated, you begin to walk away from the maze.")
            s_var = input("(enter)")
            print("")
            roll_again = "n"
            pass
    else:
        pass    
else:    pass

# Make a maze minigame
# Battle 2: The Minotaur
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    print("")
    print("A mintaur roars to greet you, and throws his die your way!")
    print("Without a second thought, you hurl your die back at him.")
 
    user_die = random.randint(player_min,player_max)
    opp_die = random.randint(minotaur_min,minotaur_max)

    user_val = user_die
    opp_name = "Minotaur"
    opp_val = opp_die 
        
    fight(user_name,user_val,opp_name,opp_val)  
    
    if user_val >= opp_val:
        print("You absolutely obliterated that guy!")
        print("")
        win_val = 2
        minotaur = "yes"
        s_var = input("(enter)")
        print("")
    else:
        opp_name = "The Minotaur"
        losscon(user_name,user_val,opp_name,opp_val)
        pass
else:    pass
roll_again = "n"

# Goblin bonus
if goblin == "y":
    loot_bonus += 10
else:    pass

# Minotaur loot
if win_val == 2:
    print("The minotaur shakes the earth as he stumbles to the ground.")
    print("Behind the minotaur, you see a rectangular silhouette.")
    print("")
    s_val = input("(enter)")
    print("")
    print("It's a chest!")
    item_roll = random.randint(1,100) + loot_bonus
    if item_roll <= rare:
        print("")
        gem_val = sapphire_val
        gem_name = sapphire
        print("Inside, you find a %s!" % gem_name)
        print("You combine your %s with your %s..." % (gem_name, die_type))
        print("")
        s_var = input("(enter)")
        print("")
    elif item_roll <= mythic and i_var > rare:
        print("")
        gem_val = emerald_val
        gem_name = emerald
        print("Inside, you find a %s!" % gem_name)
        print("You combine your %s with your %s..." % (gem_name, die_type))
        print("")
        s_var = input("(enter)")
        print("")
    elif item_roll <= (unique + 10) and i_var >mythic:
        print("")
        gem_val = ruby_val
        gem_name = ruby
        print("Inside, you find a %s!" % gem_name)
        print("You have a feeling that this gem is rare.")
        s_var = input("(enter)")
        print("You combine your %s with your %s..." % (gem_name, die_type))
        print("")
        s_var = input("(enter)")
        print("")
    elif item_roll > unique + 10:
        print("")
        gem_val = diamond_val
        gem_name = diamond
        print("Inside, you find a %s!" % gem_name)
        print("You have a feeling this is a very rare gem!")
        print("")
        s_var = input("(enter)")
        print("You combine your %s with your %s..." % (gem_name, die_type))
        print("")
        s_var = input("(enter)")
        print("")
    else:        pass
else:    pass

# New dice definition and text
if polish_val >= 1 and gem_val >= 1:
    die_type = "polished " + gem_name + " " + die
    print("...and you get a %s!" % die_type)
    max_bonus += gem_val
    min_bonus += 0
    # Reset player_max to base value
    player_max = base_max
    player_max += max_bonus
    # Reset player_min to base vale
    player_min = base_min
    player_min += min_bonus
    print("")
    print("Stats:")
    print("       Max: %d" % player_max)
    print("       Min: %d" % player_min)
    print("")
    s_var = input("(enter)")
    print("")
    print("")
    print("")
    print("")
    print("")
elif gem_val >=1:
    die_type = gem_name + " " + die
    print("...and you get a %s!" % die_type)
    max_bonus += gem_val
    min_bonus = 0
    # Reset player_max to base value
    player_max = base_max
    player_max += max_bonus
    # Reset player_min to base vale
    player_min = base_min
    player_min += min_bonus
    print("")
    print("Stats:")
    print("       Max: %d" % player_max)
    print("       Min: %d" % player_min)
    print("")
    s_var = input("(enter)")
    print("")
    print("")
    print("")
    print("")
    print("")
else:    pass

# Finding the path
print("You continue wandering until you, once again, find a path.")
print("This time, however, the path is made of cobblestone and is well trodden.")
story = input("Follow the cobblestone path? (y/n): ")
print("")

# Following the path
if story == "y":
    print("Following the path, you notice that the stones are slowly turning to darker shades of grey.")
    print("The cobblestones you walk are now almost jet black, and you begin to see where this path leads.")
    s_var = input("(enter)")
    print("")
    print("The castle in front of you stands four stories tall, but no light can be seen coming from any windows.")
    story = input("Would you like to explore the castle? (y/n): ")
    print("")
    if story == "y":
            print("When you walk inside, you find an unlit torch and some flint.")
            print("You light the torch, and begin your search.")
            print("")
            castle = "y"
    else:   pass
else:    pass 

i_var = random.randint(1,100)
if win_val != 2 and win_val != 1:
    i_var += 50
elif win_val != 2 or win_val != 1:
    i_var += 25
    pass

s_var = "m"
# Exploring the castle
if story == "y" and i_var >= 75:
    print("Exploring the castle, you eventually find a library.")
    s_var = input("Explore the library or move on? (e/m): ")
    print("")
else:    pass

# Library scene
if s_var == "e":
    print("You begin to thumb through some of the books and as you pull one of the larger books off of the shelf...")
    print("...you hear stone grinding against stone and see the the wall next to you is slowly lowering.")
    s_var = input("Look in the room? (y/n): ")
    print("")
    if s_var == "y":
            print("In the center of the hidden room, you see a lone pedistal;  on it, you see a book.")
            print("The Book is titled 'Dice throwing for beginners'.")
            print("Thumbing through a few pages, you pick up a new throwing technique!")
            max_bonus += 2
            min_bonus += 3
            # Reset player_max to base value
            player_max = base_max
            player_max += max_bonus
            # Reset player_min to base vale
            player_min = base_min
            player_min += min_bonus
            print("")
            print("Stats:")
            print("       Max: %d" % player_max)
            print("       Min: %d" % player_min)
            print("")
    else:
        print("You continue exploring, happy with how you spent your time.")
        pass
else:   pass

# Redefine roll_again + gargoyle intro starts
if story == "y":
    print("As you walk the desolate halls, you can't help but feel as though you've been here before.")
    s_var = input("(enter)")
    print("")
    print("Rouding the corner, you see a large statue and a chill runs down your spine.")
    s_var = input("(enter)")
    print("")
    roll_again = "y"
else:   pass

# Battle 3: Gargoyle
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    print("The statue begins to crack, and you realize that the statue is actually a gargoyle!")
    s_var = input("(enter)")
    print("")
 
    user_die = random.randint(player_min, player_max)
    opp_die = random.randint(gargoyle_min, gargoyle_max)

    user_val = user_die
    opp_name = "Gargoyle"
    opp_val = opp_die 
        
    fight(user_name,user_val,opp_name,opp_val)  
    
    if user_val >= opp_val:
        print("The gargoyle shatters, leaving behind a pile of dust.")
        print("")
        win_val = 3
        gargoyle = "y"
        s_var = input("(enter)")
        print("")
    else:
        opp_name = "a gargoyle"
        losscon(user_name,user_val,opp_name,opp_val)
        pass
else:   pass
roll_again = "n"

# Minotaur bonus
if minotaur == "y":
    loot_bonus += 15
else:    pass

# Gargoyle loot
if gargoyle == "y":
    item_roll = random.randint(1,100)
    if loot_bonus == 0:
        loot_bonus = 50
    else:   pass  
    max_bonus += (int(item_roll/10) + loot_bonus/5)
    min_bonus += (int(item_roll/10) + loot_bonus/5)
    # Reset player_max to base value
    player_max = base_max
    player_max += max_bonus
    # Reset player_min to base vale
    player_min = base_min
    player_min += min_bonus
    print("The gargoyle dust starts to stir, and slowly moves towards your die.")
    print("Your die appears to be absorbing the gargoyle's essence, strengthening it significantly!")
    print("")
    print("(enter)")
    print("")
    die_type = "soul infused die"
    print("You are now using a %s!" % die_type)
    print("")
    print("Stats:")
    print("       Max: %d" % player_max)
    print("       Min: %d" % player_min)
    print("")
    s_var = input("(enter)")
    print("")
else:   pass

if castle == "y":
    roll_again = input("Continue exploring the castle? (y/n): ")
    print("")
else:   pass

# Battle 4: Werewolf
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    story = "y"
    if story == "y":
        print("You walk up a tall winding staircase to the top floor of the castle.")
        print("Reaching the top of the staircase, you see a large open hall with windows from floor to ceiling.")
        print("")
        s_var = input("(enter)")
        print("")
        print("The hall is long with rows of tables in the center and tattered tapestries lining the walls.")
        print("At the other end of the hall the last of the light from the full moon hits a throne.")
        print("")
        s_var = input("(enter)")
        print("")
        print("Since it's been a long day, you decide to sit down and rest for a little.")
        print("")
        s_var = input("(enter)")
        print("")
        print("As you cross the hall, you hear growling behind you...")
        print("")
        s_var = input("(enter)")
        print("")
        print("It's a werewolf! You send your die hurtling at it!")
        print("")
        s_var = input("(enter)")
        print("")
    else:   pass
    
    user_die = random.randint(player_min, player_max)
    opp_die = random.randint(werewolf_min, werewolf_max)

    user_val = user_die
    opp_name = "Werewolf"
    opp_val = opp_die 
        
    fight(user_name,user_val,opp_name,opp_val)  
    
    if user_val >= opp_val:
        print("The werewolf howls as it falls to its knees, and then to the floor.")
        print("")
        win_val = 4
        werewolf = "y"
        s_var = input("(enter)")
        print("")
    else:
        opp_name = "a werewolf"
        losscon(user_name,user_val,opp_name,opp_val)
        pass    
    if story == "y":
        print("The morning light begins to creep into the hall, and touches the werewolf.")
        print("")
        s_var = input("(enter)")
        print("")
        print("Before you, the werewolf begins to transform back into a human.")
        print("After a few seconds, the man lying at your feet gasps for air.")
        print("")
        s_var = input("(enter)")
        print("")
        print("Man: Sire...I'm sorry, I should have known that it was you.")
        print("")
        print("The man's voice is hoarse and slow.")
        print("")
        s_var = input("(enter)")
        print("")
        print("Man: Here is your crown, your grace.")
        print("The man is clearly gaining strength.")
        print("")
        print("(enter)")
        print("")
        print("As the he gets up, the man hands you a golden crown.")
        print("Man: I have kept this treasure safe from bandits and scavengers for many years now...")
        print("     ...and at last, you finally return! but there is something changed about you, isn't there?")
        print("You look at him, puzzled and cautious.")
        print("")
        s_var = input("(enter)")
        print("")
        print("Man: Do you not recognize your right hand man, your grace? I am Ned, protector of the crown!")
        print("Ned: Can you remember what happened to you? Last time I saw you, you were heading to Mount Hrothgar.")
        print("")
        s_var = input("(enter)")
        print("")
        print("%s: Why did I go to Mount Hrothgar?" % user_name)
        print("")
        s_var = input("(enter)")
        print("")
        print("Ned: You weren't very clear about that, your grace.")
        print("Ned: All you said was that you felt drawn to it, and that you had unfinished business there.")
        print("")
        print("You recall the strange felling from earlier and begin to believe what Ned is saying.")
        print("")
        s_var = input("(enter)")
        print("")
        print("%s: Where is Mount Hrothgar, Ned?" % user_name)
        print("")
        print("Ned: North of the castle, your grace.")
        print("")
        s_var = input("(enter)")
        print("")
        print("%s: I must go there at once. With the information you've given me I can no longer deny my destiny." % user_name)
        print("%s: Wait here, Ned, and watch over my throne." % user_name) 
        print("")
        print("Ned: As you wish sire.")
        print("")
        s_var = input("(enter)")
        print("")
    else:   pass
else:   pass
roll_again = "n"

# Gargoyle bonus
if gargoyle == "y":
    loot_bonus += 20
else:   pass

user_adj = "Brave" # Make a table with random adjectives
# Werewolf win
if win_val == 4:
    print("As you walk away from Ned, you put on your crown.")
    print("The feeling is unmistakable now. You know who you are, you are King %s, the %s!"% (user_name, user_adj))
    item_roll = random.randint(1,100) + loot_bonus
    if item_roll <= 75:
        max_bonus += 10
        min_bonus += 10
    elif item_roll <= 130:
        max_bonus += 15
        min_bonus += 15
    else:
        max_bonus += 20
        min_bonus += 20
    pass
    # Reset player_max to base value
    player_max = base_max
    player_max += max_bonus
    # Reset player_min to base vale
    player_min = base_min
    player_min += min_bonus
    print("")
    print("Your die grows in strength!")
    print("")
    print("Stats:")
    print("")
    print("       Max: %d" % player_max)
    print("       Min: %d" % player_min)
    print("")
    s_var = input("(enter)")
    print("")
    print("")
    print("")
    print("")
    print("")
else:   pass

# Post werewolf story
if werewolf == "y":
    print("As you walk out through the castle gates, you are greeted by the morning sun ahead of you.")
    print("You look up to the sky, take a deep breath, and start walking north towards Mount Hrothgar.")
    print("")
    s_var = input("(enter)")
    print("")
else:   pass  

# Level 4: Werewolf on roof or main hall (big windows)
# Chance of sun coming up and making a friend 
# After defeating the werewolf the strange presence guides your eyes towards the mountains in the distance
# Solve a riddle on the road to get a new die?

# Final level: Blue-Eyes White Dragon # Not knowing what awaits you beyond, you boldy go where no man has gone before.

#Final secret level opens if you kill all monsters? Secret level unlock: print("as you continue your journey, you feel a strange presence drawing you east...")

# Scenario for if you skip every event where it talks about your boring day...other than running from that firghtful goblin, of course
# add text-based pictures of the enemies/npc's