import random

# Integer definitions
user_val = 1
opp_val = 0
max_bonus = 0
min_bonus = 0
i_var = 0
win_val = 0
secret = 0
dialogue_int = 0
riddle_int = 0

loot_ints = 0
if loot_ints == 0:
    # Item Rarities
    common = 10
    uncommon = 25
    rare = 50
    mythic = 75
    unique = 90
    wild = 100

    loot_bonus = 0
    item_roll = 0
    polish_val = 0

    gem_val = 0
    sapphire_val = 5
    emerald_val = 10
    ruby_val = 15
    diamond_val = 20
else:    pass
loot_strings = "y"
if loot_strings == "y":
    polish_str = "polish"
    gem_name = ""
    sapphire = "sapphire"
    emerald = "emerald"
    ruby = "ruby"
    diamond = "diamond"
else:    pass

dice_perameters = 0
if dice_perameters == 0:
    user_die = 0
    opp_die = 0
    base_max = 6
    base_min = 3

    player_max = base_max
    player_min = base_min

    goblin_max = base_max - 2
    goblin_min = base_min - 2

    minotaur_max = base_max
    minotaur_min = base_min

    gargoyle_max = base_max * 2 - 1
    gargoyle_min = base_min * 2 - 1

    werewolf_max = base_max * 3 + 2
    werewolf_min = base_min * 3 + 1

    blue_eyes_max = base_max * 8
    blue_eyes_min = base_min * 8
else:    pass

# gold = formula based on chace of you winning a given battle

# Evetually make the enemy names in thr game dependent on these variables aka opponent_1 = "goblin"
# Opens opportuity for building more functions i think?
story_strings = "y"
if story_strings == "y":
    roll_again = "y"
    user_name = "username"
    opp_name = "oppoonent"
    story = "intro"
    s_var = "nothing"
    castle = "n"
    dialogue = "none"
    dialogue_2 = "none"
    riddle_str = "n"
    key_of_time = "n"
    stone_door = "n"
    royal_gender = "n"

    goblin = "n"
    minotaur = "n"
    gargoyle = "n"
    werewolf = "n"
    blue_eyes = "n"
else:    pass

# String definitions
material = "wood"
adj = "rough"
die = "die"
die_type = adj + " " + material + " " + die
enter_variable = "n"

def losscon(user,userval,opponent,oppval):
    if userval < oppval:   
        print("")
        print("")
        print("")
        print("")
        print("")    
        print("%s, you've been defeated by %s." % (user,opponent))
        print("You lose.")
        print("")
        print("")
        print("")
        print("")
        print("")
        exit()
    else:
        pass

def fight(user,userval,opponent,oppval):
    # 'Fight scene' message
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("You roll the dice at eachother...")
    print("...and the values are...")
    print("")
    # Accounting for a tie, defaulting to opponent1
    if userval - oppval == 0: 
        userval += 1
    else:
        userval = userval
        pass
    # Fight output on screen
    print("%s: %d" % (user,userval))
    print("%s: %d" % (opponent,oppval))
    print("")    

# defines the 'enter' prompt   
def enter():
    print("")
    enter_variable = input("(enter)")
    print("")

if story == "intro":
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    royal_gender = input("Are you male or female? (m/f): ")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("")
    print("You wake up alone in the middle of a vast forest with a full moon overhead...")
    print("")
    user_name = input("...as you regain conciousness, you try to remember your name: ")
    print("")
    print("You reach your hand in your pocket and find a %s." % die_type)
    print("")
    print("Stats:")
    print("")
    print("       Max: %d" % player_max)
    print("       Min: %d" % player_min)
    print("")
    roll_again = input("Press (enter) to start your journey, %s. " % user_name)
    print("")
else:    pass

if royal_gender == "m":
    royal_gender = "King"
else:
    royal_gender = "Queen"
    pass

print("While roaming through the forest, you notice a figure emerge from behind a tree.")
print("As you aproach the figure, you realize that it's a goblin!")
story = input("Fight, or run? (f/r): ")
print("")
roll_again = "y"
if story == "r": # make it so that theres a chance the goblin catches you!!!!!
    roll_again = "n"
else:    pass

# Battle 1: Goblin
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    
    user_die = random.randint(player_min,player_max)
    opp_die = random.randint(goblin_min,goblin_max)

    user_val = user_die
    opp_name = "Goblin"
    opp_val = opp_die
    
    fight(user_name,user_val,opp_name,opp_val)

    if user_val >= opp_val:
        print("You've smashed the goblin to bits!")
        roll_again = input("(enter)")
        print("")
        win_val = 1
        secret += 1
        goblin = "y"
    else:
        opp_name = "a goblin"
        losscon(user_name,user_val,opp_name,opp_val)
        pass
else:    pass
roll_again = "n"

# Goblin Reward
if win_val == 1:
    item_roll = random.randint(1,100)
    if item_roll > common:
        print("You notice a small vial next to your fallen opponent.")
        print("It's a Vial of Polish!")
        polish_str = input("Use, or discard the polish? (u/d): ")
        print("")
        if polish_str == "u":
            polish_val = 4
            die_type = "Polished Wood Die"
            print("")
            print("You are now using a %s!" % die_type)
            print("")
            max_bonus += polish_val
            min_bonus += polish_val - 3
            player_max = base_max
            player_max += max_bonus
            player_min = base_min
            player_min += min_bonus
            print("")
            print("Stats:")
            print("       Max: %d" % player_max)
            print("       Min: %d" % player_min)
            print("")
            print("With great power, comes great responsibility.")
            print("")
            roll_again = input("(enter)")
            print("")
        else:
            print("You drop the vial and it shatters on a rock...")
            print("")
            pass
    else:
        pass    
else:    pass

# Finding the dirt path
print("After the excitement with the goblin, you decide to rest and regain your strength.")
story = input("Once your heart finally calms down, you continue your journey. (enter)")
print("")
print("You walk for an hour or so and find a barely visible dirt path.")
story = input("Do you follow it? (y/n): ")
print("")
if story == "y":
    print("You follow the path as it winds through the trees; ahead you begin to see a clearing.")
    print("As you draw nearer to the clearing, the moonlight hits your face and you make out what appears to be a wall of large hedges.")
    enter()
    print("After walking along the wall, you find an entrance to a maze!")
    s_var = input("Would you like to make an attempt at solving the maze? (y/n): ")
    print("")
    if s_var == "y":
        i_var = random.randint(1,100)
        if goblin == "n":
            i_var += 20
        else:
            pass
        if i_var > uncommon:
            roll_again = "y"
            print("While walking through the maze, you notice a faint light being emitted around the corner.")
            print("You slowly aproach the corner, preparing yourserlf for whatever awaits you.")
            enter()
        else:
            print("You walk around the maze for a while, but end up at a different entrance.")
            print("Feeling a little defeated, you begin to walk away from the maze.")
            enter()
            print("")
            roll_again = "n"
            pass
    else:
        pass    
else:    pass

# Battle 2: The Minotaur
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    print("")
    print("A mintaur roars to greet you, and throws his die your way!")
    print("Without a second thought, you hurl your die back at him.")
 
    user_die = random.randint(player_min,player_max)
    opp_die = random.randint(minotaur_min,minotaur_max)

    user_val = user_die
    opp_name = "Minotaur"
    opp_val = opp_die 
        
    fight(user_name,user_val,opp_name,opp_val)  
    
    if user_val >= opp_val:
        print("You absolutely obliterated that guy!")
        print("")
        win_val = 2
        secret += 1
        minotaur = "yes"
        enter()
        print("")
    else:
        opp_name = "The Minotaur"
        losscon(user_name,user_val,opp_name,opp_val)
        pass
else:    pass
roll_again = "n"

# Goblin bonus
if goblin == "y":
    loot_bonus = loot_bonus + 10
else:    pass

# Minotaur loot
if win_val == 2:
    print("The minotaur clumsily stumbles to the ground.")
    print("Behind the minotaur, you see a rectangular silhouette.")
    enter()
    print("It's a chest!")
    print("")
    item_roll = random.randint(1,100) + loot_bonus
    item_roll = 90
    if item_roll <= rare:
        print("")
        gem_val = sapphire_val
        gem_name = sapphire
        print("Inside, you find a %s!" % gem_name)
        print("You combine your %s with your %s..." % (gem_name, die_type))
        enter()
    elif item_roll <= mythic and item_roll > rare:
        print("")
        gem_val = emerald_val
        gem_name = emerald
        print("Inside, you find a %s!" % gem_name)
        print("You combine your %s with your %s..." % (gem_name, die_type))
        enter()
    elif item_roll <= unique and item_roll > mythic:
        print("")
        gem_val = ruby_val
        gem_name = ruby
        print("Inside, you find a %s!" % gem_name)
        print("You have a feeling that this gem is pretty rare.")
        enter()
        print("You combine your %s with your %s..." % (gem_name, die_type))
        enter()
    elif item_roll > unique:
        print("")
        gem_val = diamond_val
        gem_name = diamond
        print("Inside, you find a %s!" % gem_name)
        print("You have a feeling this is a very rare gem!")
        print("")
        enter()
        print("You combine your %s with your %s..." % (gem_name, die_type))
        enter()
    else:        pass
else:    pass

# New dice definition and text
if polish_val >= 1 and gem_val >= 1:
    die_type = "polished " + gem_name + " " + die
    print("...and you get a %s!" % die_type)
    max_bonus += gem_val
    min_bonus += 0
    # Reset player_max to base value
    player_max = base_max
    player_max += max_bonus
    # Reset player_min to base vale
    player_min = base_min
    player_min += min_bonus
    print("")
    print("Stats:")
    print("")
    print("       Max: %d" % player_max)
    print("       Min: %d" % player_min)
    print("")
    enter()
    print("")
    print("")
    print("")
    print("")
    print("")
elif gem_val >=1:
    die_type = gem_name + " " + die
    print("...and you get a %s!" % die_type)
    max_bonus += gem_val
    min_bonus = 0
    # Reset player_max to base value
    player_max = base_max
    player_max += max_bonus
    # Reset player_min to base vale
    player_min = base_min
    player_min += min_bonus
    print("")
    print("Stats:")
    print("       Max: %d" % player_max)
    print("       Min: %d" % player_min)
    print("")
    enter()
    print("")
    print("")
    print("")
    print("")
    print("")
else:    pass

# Finding the Cobblestone path
print("You continue wandering until you, once again, find a path.")
print("This time, the path is made of cobblestone and looks as though it was once used often. ")
print("However, there are now plants growing through some of the cracks and it is littered with plant debreis.")
print("")
story = input("Follow the cobblestone path? (y/n): ")
print("")

# Following the path
if story == "y":
    print("Following the path, you notice that the stones are slowly turning to darker shades of grey.")
    print("The cobblestones you walk are now almost jet black, and you begin to see where this path leads.")
    enter()
    print("")
    print("The castle in front of you stands four stories tall, but no light can be seen coming from any windows.")
    story = input("Would you like to explore the castle? (y/n): ")
    print("")
    if story == "y":
            print("When you walk inside, you find an unlit torch and some flint.")
            print("You light the torch, and begin your search.")
            print("")
            castle = "y"
    else:   pass
else:    pass 

i_var = random.randint(1,100)
if win_val != 2 and win_val != 1:
    i_var += 50
elif win_val != 2 or win_val != 1:
    i_var += 25
    pass

s_var = "m"
# Exploring the castle
if story == "y" and i_var >= 75:
    print("Exploring the castle, you eventually find a library.")
    s_var = input("Explore the library or move on? (e/m): ")
    print("")
else:    pass

# Library scene
if s_var == "e":
    print("You begin to thumb through some of the books and as you pull one of the larger books off of the shelf...")
    print("...you hear stone grinding against stone and see the the wall next to you is slowly lowering.")
    s_var = input("Look in the room? (y/n): ")
    print("")
    if s_var == "y":
            print("In the center of the hidden room, you see a lone pedistal;  on it, you see a book.")
            print("The Book is titled 'Dice throwing for beginners'.")
            print("Thumbing through a few pages, you pick up a new throwing technique!")
            max_bonus += 2
            min_bonus += 3
            # Reset player_max to base value
            player_max = base_max
            player_max += max_bonus
            # Reset player_min to base vale
            player_min = base_min
            player_min += min_bonus
            print("")
            print("Stats:")
            print("       Max: %d" % player_max)
            print("       Min: %d" % player_min)
            print("")
    else:
        print("You continue exploring, happy with how you spent your time.")
        pass
else:   pass

# Redefine roll_again + gargoyle intro starts
if story == "y":
    print("As you walk the desolate halls, you can't help but feel as though you've been here before.")
    enter()
    print("")
    print("Rouding the corner, you see a large statue and a chill runs down your spine.")
    enter()
    print("")
    roll_again = "y"
else:   pass

# Battle 3: Gargoyle
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    print("The statue begins to crack, and you realize that the statue is actually a gargoyle!")
    enter()
    print("")
 
    user_die = random.randint(player_min, player_max)
    opp_die = random.randint(gargoyle_min, gargoyle_max)

    user_val = user_die
    opp_name = "Gargoyle"
    opp_val = opp_die 
        
    fight(user_name,user_val,opp_name,opp_val)  
    
    if user_val >= opp_val:
        print("The gargoyle shatters, leaving behind a pile of dust.")
        print("")
        win_val = 3
        secret += 1
        gargoyle = "y"
        enter()
        print("")
    else:
        opp_name = "a gargoyle"
        losscon(user_name,user_val,opp_name,opp_val)
        pass
else:   pass
roll_again = "n"

# Minotaur bonus
if minotaur == "y":
    loot_bonus += 15
else:    pass

# Gargoyle loot
if gargoyle == "y":
    item_roll = random.randint(1,100)
    if loot_bonus == 0:
        loot_bonus = 50
    else:   pass  
    max_bonus += (int(item_roll/10) + loot_bonus/5)
    min_bonus += (int(item_roll/10) + loot_bonus/5)
    # Reset player_max to base value
    player_max = base_max
    player_max += max_bonus
    # Reset player_min to base vale
    player_min = base_min
    player_min += min_bonus
    print("The gargoyle dust starts to stir, and slowly moves towards your die.")
    print("Your die appears to be absorbing the gargoyle's essence, strengthening it significantly!")
    print("")
    enter()
    print("")
    die_type = "soul infused die"
    print("You are now using a %s!" % die_type)
    print("")
    print("Stats:")
    print("       Max: %d" % player_max)
    print("       Min: %d" % player_min)
    print("")
    enter()
    print("")
else:   pass

if castle == "y":
    roll_again = input("Continue exploring the castle? (y/n): ")
    print("")
else:   pass

# Battle 4: Werewolf
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    story = "y"
    if story == "y":
        print("You walk up a tall winding staircase to the top floor of the castle.")
        print("Reaching the top of the staircase, you see a large open hall with windows from floor to ceiling on either end.")
        enter()
        print("The hall is long with rows of tables in the center and tattered tapestries lining the walls.")
        print("At the other end of the hall the last of the light from the full moon hits a throne.")
        enter()
        print("Since it's been a long day, you decide to sit down and rest for a little.")
        enter()
        print("You sit down on what you now realize is a throne, and watch the moon slowly slip below the horizon.")
        print("As the room darkens, you begin to dose off...")
        enter()
        print("You awaken to the sound of footsteps...then you hear a growl, and your eyes open wide...")
        enter()
        print("It's a werewolf!")
        print("You send your die hurtling at it!")
        enter()
    else:   pass
    
    user_die = random.randint(player_min, player_max)
    opp_die = random.randint(werewolf_min, werewolf_max)

    user_val = user_die
    opp_name = "Werewolf"
    opp_val = opp_die 
        
    fight(user_name,user_val,opp_name,opp_val)  
    
    if user_val >= opp_val:
        print("The werewolf howls as it falls to its knees, and then to the floor.")
        print("")
        win_val = 4
        secret += 1
        werewolf = "y"
        enter()
        print("")
    else:
        opp_name = "a werewolf"
        losscon(user_name,user_val,opp_name,opp_val)
        pass    
    if story == "y":
        print("The morning light begins to creep into the hall, and touches the werewolf.")
        enter()
        print("Before you, the werewolf begins to transform back into a human.")
        print("After a few seconds, the man lying at your feet gasps for air.")
        enter()
        print("Man: Sire...I'm sorry, I should have known that it was you.")
        print("")
        print("The man's voice is hoarse and slow.")
        enter()
        print("Man: Here is your crown, your grace.")
        print("The man is clearly gaining strength.")
        print("")
        print("(enter)")
        print("")
        print("As the he gets up, the man hands you a golden crown.")
        print("")
        print("Man: I have kept this treasure safe from bandits and scavengers for many years now...")
        print("     ...and at last, you finally return! but there is something changed about you, isn't there?")
        print("")
        print("You look at him, puzzled and cautious.")
        enter()
        print("Man: Do you not recognize your right hand man, your grace? I am Ned, protector of the crown!")
        print("Ned: Can you remember what happened to you? Last time I saw you, you were heading to Mount Hrothgar.")
        enter()
        print("%s: Why did I go to Mount Hrothgar?" % user_name)
        enter()
        print("Ned: You weren't very clear about that, your grace.")
        print("Ned: All you said was that you felt drawn to it, and that you had unfinished business there.")
        print("")
        print("You recall the strange feeling from earlier and begin to believe what Ned is saying.")
        enter()
        print("%s: Where is Mount Hrothgar, Ned?" % user_name)
        print("")
        print("Ned: North of the castle, your grace.")
        enter()
        print("%s: I must go there at once. With the information you've given me I can no longer deny my destiny." % user_name)
        print("%s: Wait here, Ned, and watch over my throne." % user_name) 
        print("")
        print("Ned: As you wish sire.")
        enter()
    else:   pass
else:   pass
roll_again = "n"

# Gargoyle bonus
if gargoyle == "y":
    loot_bonus += 20
else:   pass

user_adj = "Brave" # Make a table with random adjectives
# Werewolf win
if win_val == 4:
    loot_bonus += 25
    print("As you walk away from Ned, you put on your crown.")
    print("The feeling is unmistakable now. You know who you are, you are %s %s, the %s!"% (royal_gender, user_name, user_adj))
    item_roll = random.randint(1,100) + loot_bonus
    if item_roll <= 75:
        max_bonus += 10
        min_bonus += 10
    elif item_roll <= 130:
        max_bonus += 15
        min_bonus += 15
    else:
        max_bonus += 20
        min_bonus += 20
    pass
    # Reset player_max to base value
    player_max = base_max
    player_max += max_bonus
    # Reset player_min to base vale
    player_min = base_min
    player_min += min_bonus
    print("")
    print("Your die grows in strength!")
    print("")
    print("Stats:")
    print("")
    print("       Max: %d" % player_max)
    print("       Min: %d" % player_min)
    print("")
    enter()
    print("")
    print("")
    print("")
    print("")
    print("")
else:   pass

# Post werewolf story
if werewolf == "y":
    print("As you walk out through the castle gates, you are greeted by the morning sun ahead of you.")
    print("You look up to the sky, take a deep breath, and set your gaze on Mount Hrothgar as you begin your final journey.")
    enter()
    print("It's now midday, and as you walk through the forest the birds, squirrels, and other animals are active all around.")
    print("You feel at home in the woods, as if most of your life had been spent hunting and wandering through them.")
    print("To your left, there is a rockface stretching hundreds of feet tall.")
    print("You recognize this rockface...but can't quite remember what the significance of it is.")
    enter()
else:   pass    

# Random encounter: The Door
story = "n"
i_var = random.randint(1,100)
if minotaur != "y":
    i_var = i_var + 25
elif goblin != "y":
    i_var = i_var + 30
else:   pass
if i_var >= rare and werewolf == "y":
    print("As you study the rockface, you recognize the carvings of a stone door.")
    print("")
    s_var = input("Approach the door? (y/n): ")
    print("")
    if s_var == "y":
        print("The door reads 'Speak friend, and enter'")
        print("")
        s_var = input("%s: " % user_name)
        print("")
        if s_var == "friend" or s_var == "Friend":
            stone_door = "y"
        else:
            print("The carvings on the door slowly begin to disappear.")
            print("Confused, you continue along the way you were traveling.")
            enter()
            pass
    else:
        print("You continue along the way you were traveling.")
        enter()
        pass
elif win_val == 4:
    print("After a couple of minutes the presence guides you back on course, and you walk towards Mount Hrothgar once more.")
    enter()
    pass

if stone_door == "y":
    print("The door slowly lowers; inside you find a strange looking die sitting on the ground.")
    print("")
    stone_door = input("Pick up the die? (y/n): ")
    print("")
    if stone_door == "y":
        print("You pick up the die and you hear a whisper behind you...")
        print("")
        print("Mysterious Voice: ...freedom...")
        enter()
        print("You turn around to see who is behind you, and see nothing but an empty doorframe.")
        print("You examine the strange die and realize that it is even more powerful than your own!")
        print("")
        s_var = input("Replace your %s with the strange die? (y/n): " % die_type)
        print("")
        if s_var == "y":
            die_type = "strange die"
            max_bonus += 15
            player_max = base_max
            player_max += max_bonus
            min_bonus += 15
            player_min = base_min
            player_min += min_bonus
            print("")
            print("You now weild the %s!" % die_type)
            print("")
            print("Stats:")
            print("")
            print("       Max: %d" % player_max)
            print("       Min: %d" % player_min)
            enter()
        else:
            print("You place the die back where you found it.")
            print("Unsure about the consequences of your actions, you continue to Mount Hrothgar.")
            print("")
            pass

    else:   pass
else:   pass    

story = "n"
if win_val == 4:
    story = "y"
else:
    story = "n"
    pass
 # need to write climbing text
if story == "y":
    print("You finally make it to the base of mount Hrothgar.")
    enter()
    print("Preparing yourself for what lies ahead, you slowly make your way up the mountain.")
    enter()
    print("After climbing for a while you feel the temperature significantly drop")
else:   pass

# Key guardian
if story == "y":
    print("")
    print("")
    print("")
    print("")
    print("")
    print("An apparition manifests in front of you.")
    print("")
    print("Apparition: Welcome adventurer; have you come to test your abilities?")
    print("")
    print("    a: I have come to fulfill my destiny. Who are you?")
    print("    b: Out of my way, peasant!")
    print("    c: What's happening? I don't understand.")
    print("")
    dialogue = input("(a/b/c) ")
    print("")
else:   pass

if dialogue == "a" or dialogue == "c":
    print("Apparition: I am Leanna, Queen of the Mountains, and this is my domain.")
    print("Leanna: If you wish to face the opponent you seek, you must first answer my riddle.")
    print("")
    print("    a: I accept.")
    print("    b: Riddles are a waste of my time, let me through or feel my wrath!")
    print("    c: Can you just let me through that door behind you?")
    print("")
    dialogue_2 = input("(a/b/c) ")
    print("")
elif dialogue == "b":
    print("Apparition: You should consider my proposal, the only way to continue is with my blessing.")
    print("Apparition: For I am Leanna, Queen of the Mountains, and this is my domain.")
    enter()
    print("Leanna: If you will not solve my riddle, you must leave this place.")
    print("Leanna: However, if you do complete it I will present you with the Key of Time, granting you passage to the Ceremonial Chamber.")
    print("")
    s_var = input("Will you comply? (y/n): ")
    print("")
    if s_var == "y":
        dialogue_2 = "a"
    else:
        print("You turn your back to Leanna, frustratedly walking back to the castle.")
        print("")
        pass
    pass
pass

if dialogue_2 == "b":
    print("Leanna: Aggression will get you nowhere, you can only continue by completing my riddle.")
    print("Leanna: If you will not solve my riddle, you must leave this place.")
    print("Leanna: However, if you do complete it I will present you with the Key of Time, granting you passage to the Ceremonial Chamber.")
    print("")
    s_var = input("Will you comply? (y/n): ")
    print("")
    if s_var == "y":
        dialogue_2 = "a"
    else:
        print("You turn your back to Leanna, frustratedly walking back to the castle.")
        print("")
        pass
else:  pass

if dialogue_2 == "c":
    item_roll = random.randint(1,75) + loot_bonus
    if item_roll >= wild:
        print("Leanna: There is...a strange familiarity to you.")
        print("Leanna: I don't know why, but I feel compelled to allow you to pass.")
        enter()
        print("Leanna: Here is the Key of Time. Use it to open the Ceremonial Chamber Door.")
        key_of_time = "y"
        print("Leanna: But proceed with caution, adventurer.")
        print("Leanna: If you fail, your soul shall be stripped from your body, and devoured by the best.")
        print("Leanna: If you do survive, however, we may meet again...")
        enter()
    else: 
        print("Leanna: You are no exception to my rules.")
        print("Leanna: Accept my proposal, or leave my lands at once.")
        print("")
        dialogue_2 = input("Accept, or reject? (a/r): ")
        print("")
        pass
else: pass

# Table of varioius riddles and answers
if dialogue_2 == "a":
    while key_of_time != "y":
        print("")
        print("")
        print("")
        print("")
        print("")
        print("The riddle is as follows: ")
        print("")
        print("    A grandfather, two fathers, and two sons walk into a tavern.")
        print("    Each member of the party buys their own drink.")
        print("")
        print("    How many drinks did the party buy?")
        print("")
        riddle_str = input("Answer: ")
        print("")
        if riddle_str == "3":
            print("Leanna: You are more cunning than I thought.")
            print("Leanna: Because you have solved this riddle, you have earned passage into the Ceremonial Chamber.")
            enter()
            print("Leanna: I present to you, The Key to Time.")
            key_of_time = "y"
            print("Leanna: With this key, you will find the answers you seek, but be wary!")
            print("Leanna: Many have come to face this challenge before you and failed.")
            print("Leanna: Should you fail to conquor your foe, the price to be paid will be your soul.")
            print("Leanna: I have a feeling that if you achieve your goal, we will be seeing eachother oncemore...")
            print("Leanna: Go now, and fulfill your destiny!")
            print("")
            print("With those final words, the Queen of the Mountains disappated.") 
            enter()
            print("You are left staring at the ornate door infront of you, wondering what challenge could be awaiting you.")
            enter()
        else:
            print("Try again.")
            pass
else:   pass

# Final level: Blue-Eyes White Dragon
if key_of_time == "y" :
    story = "y"
    if story == "y":
        print("As you approach the Ceremonial Chamber Door, its runic inscriptions glow with a faint blue hue.")
        print("By the time you reach the door the symbols are glowing vividly.")
        enter()
        print("You lift the key towards the lock...")
        enter()
        print("...and as you touch key to stone, there's a blinding flash!")
        enter()
        print("The inscriptions are now a vivid red.")
        print("Your body shakes as the immense stone door lowers into the ground and reveals the Ceremonial Chamber.")
        enter()
        print("The Chamber is cavernous, with torches on the wall shining red light throughout.")
        print("There are large stalactites hanging from the ceiling and a large cage behind a boulder in the back.")
        print("The center of the room has an enlaerged version of the runed seal that you saw on the door to the chamber.")
        print("You continue walking through this vast chamber, and you see a glimmer of light come from the boulder.")
        enter()
        print("You slowly approach the boulder...")
        enter()
        print("...and it begins to move!")
        enter()
        print("It's the Blue-Eyes White Dragon!")
        print("He rises, and looks at you fiercely.")
        enter()
        print("")
        print("")
        print("Blue-Eyes: I wondered when I would see you again, %s." % user_name)
        enter()
        print("%s: How do you know who I am?" % user_name)
        enter()
        print("Blue-Eyes: I am your mortal enemy, we have known one another for centuries.")
        enter()
        print("%s: Centuries...how can this be? Explain your riddles, dragon!" % user_name)
        enter()
        print("Blue-Eyes: I speak no riddles, that job is left to your wife.")
        print("")
        print("The dragon smirked.")
        enter()
        print("%s: Leanna...is my wife?" % user_name)
        enter()
        print("Blue-Eyes: Very good, %s, I can see you're starting to remember." % user_name)
        enter()
        print("")
        print("")
        print("You recall bits and pieces of the final moments leading up to your death.")
        print("In your mind, you see an image of Leanna in a cage behind the dragon.")
        enter()
        print("'Fool! I knew if I captured your partner you would attempt to rescue her,' the dragon said.")
        print("'Now you will both be my prey! I will trap you, oh yes, but not physically,' he continued.")
        print("'You will both be in a never ending cycle of time, repeating the same actions for eternity,' he threatened.")
        print("'Leanna will puzzle you, %s, and I will kill you; from now, until the end of time!'" % user_name)
        enter()
        print("")
        print("")
        print("You stare angrily at the dragon, years of hatred boiling inside of you.")
        print("")
        print("%s: You're the reason I've lost my memory!" % user_name)
        print("%s: You're the reason my wife and I cannot rest!" % user_name)
        print("%s: Prepare to meet your match, beast!" % user_name)
        enter()

    else:   pass
    
    user_die = random.randint(player_min, player_max)
    opp_die = random.randint(blue_eyes_min, blue_eyes_max)

    user_val = user_die
    opp_name = "Blue-Eyes White Dragon"
    opp_val = opp_die 
        
    fight(user_name,user_val,opp_name,opp_val)  
    
    if user_val >= opp_val:
        print("The ground trembles beneath your feet as the Blue-Eyes White Dragon comes roaring down next to you.")
        print("")
        win_val = 4
        secret += 1
        blue_eyes = "y"
        story = "y"
        enter()
        print("")
    else:
        print("You fall to your knees as the dragon roars with laughter.")
        enter()
        print("Blue-Eyes: Better luck next time, %s." % user_name)
        print("He said with a smile.")
        enter()
        exit()
    if story == "y":
        print("")
        print("")
        print("")
        print("The dragon's body begins to fade from existence.")
        enter()
        print("As you watch it's body disappear, you hear a familiar voice from behind you.")
        enter()
        print("Leanna: We can finally rest now, %s." % user_name)
        print("Leanna: Let us move on from this world, and begin a new journey together.")
        enter()
        print("You take Leanna's hand, and move on to something greater.")
        enter()
    else:   pass
else:   pass
roll_again = "n"
if roll_again == "n":
    print("                              Credits")
    print("")
    print("                            Program Design")
    print("                             Rush Deeter")
    print("")
    print("                            Story Writing")
    print("                             Rush Deeter")
    print("")
    print("                            Game Testing")
    print("                             %s" % user_name)
    print("                             Wesley Hanlon")
    print("                             Dimitar Markovski")
    print("                             Keith Neely")
    print("                             Kathy Orta")
    print("                             Rush Deeter")
    print("")
    exit()
else:   pass


#Final secret level opens if you kill all monsters? Secret level unlock: print("as you continue your journey, you feel a strange presence drawing you east...")
# You're actually a ghost trying to reunite with your wife # Not knowing what awaits you beyond, you boldy go where no human has gone before.

# Scenario for if you skip every event where it talks about your boring day...other than running from that firghtful goblin, of course
# add text-based pictures of the enemies/npc's

# 1.9 will be optimization, the secret level, the pacifist condition, adding gold drops(?)

# 2.0 change the mechanics so that there is health and damage not just score comparison

# Add a store