# Imports 'random' module
import random

# Defines the 'Minimum' and 'Maximum' variables
min = 1
max = 10

# Defines the 'roll_again' and 'user_name' variables
roll_again = "y"
user_name = "nothing"

# Exits the game if the user's value is less than the opponents'
def losscon(user,userval,oppval):

    if userval < oppval:   
        print("")    
        print("%s, you lose." % user)
        print("")
    else:
        pass
    exit

def fight(user,userval,opponent,oppval):
    # 'Fight scene' message
    print("")
    print("You roll the dice at eachother...")
    print("...and the values are...")
    print("")
    # Accounting for a tie, defaulting to opponent1
    if userval - oppval == 0: 
        userval += 1
        pass
    else:
        # Fight output on screen
        print("%s: %d" % (user,userval))
        print("%s: %d" % (opponent,oppval))
        print("")    

# A welcome message/starting screen
print("")
print("Welcome adventurer!")
user_name = input("What is your name?: ")
roll_again = input("Are you ready to start, %s? (y/n): " % user_name)

# Level 1
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    
    # Defines 'user_val' and 'opp_val' as random integers between the given parameters 
    # and defines the opponenets name
    user_val = random.randint(min+6,max)
    opp_name = "Computer"
    opp_val = random.randint(min,max-6)
    
    # Calls the 'fight' function
    fight(user_name,user_val,opp_name,opp_val)

    # Checks if the user won
    if user_val > opp_val:
        print("You've smashed the computer to bits!")
        print("")
        roll_again = input("Move on to the next level? (y/n): ")
        print("")
else:
    pass

# Calls the losing condition function
losscon(user_name,user_val,opp_val)

# Level 2
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    
    user_val = random.randint(min+4,max)
    opp_name = "Computer 2.0"
    opp_val = random.randint(min,max-4)
        
    fight(user_name,user_val,opp_name,opp_val)  
    
    if user_val > opp_val:
        print("You absolutely obliterated that one!")
        print("")
        roll_again = input("Move on to the next level? (y/n): ")
        print("")
else:
    pass

losscon(user_name,user_val,opp_val)