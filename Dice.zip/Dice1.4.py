import random

# Integer definitions
user_val = 1
opp_val = 0
polish = 0
item_roll = 0
i_var = 0

# Item Rarities
common = 10
uncommon = 25
rare = 50
mythic = 75
unique = 90

x = "intro"
roll_again = "y"
user_name = "username"
opp_name = "oppoonent"
die_type = "Wooden Die"
story = "continue"
status = "neutral"
s_var = "nothing"

# Exits the game if the user's value is less than the opponents'
def losscon(user,userval,opponent,oppval):
    if userval < oppval:   
        print("")    
        print("%s, you've been defeated by %s." % (user,opponent))
        print("You lose.")
        print("")
        exit()
    else:
        pass

# Runs through the fight sequence
def fight(user,userval,opponent,oppval):
    # 'Fight scene' message
    print("")
    print("You roll the dice at eachother...")
    print("...and the values are...")
    print("")
    # Accounting for a tie, defaulting to opponent1
    if userval - oppval == 0: 
        userval += 1
        pass
    else:
        # Fight output on screen
        print("%s: %d" % (user,userval))
        print("%s: %d" % (opponent,oppval))
        print("")    

if x == "intro":
    print("")
    print("")
    print("")
    print("")
    print("")
    print("You wake up alone in the middle of a vast forest with a full moon overhead...")
    print("")
    user_name = input("...as you regain conciousness, you try to remember your name: ")
    print("")
    print("You reach your hand in your pocket and find a %s." % die_type)
    print("")
    print("Stats:")
    print("       Max: 6")
    print("       Min: 3")
    print("")
    roll_again = input("Press (enter) to start your journey, %s. " % user_name)
    print("")
else:
    pass

print("While roaming through the forest, you notice a figure emerge from behind a tree.")
print("As you aproach the figure, you realize that it's a goblin!")
story = input("Fight, or run? (f/r): ")
print("")
roll_again = "y"
if story == "r": # make it so that theres a chance the goblin catches you!!!!!
    roll_again = "n"
else:
    pass

# Level 1: Goblin
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    
    wood_die = random.randint(3,6)
        
    user_val = wood_die
    opp_name = "Goblin"
    opp_val = wood_die - 2
    
    fight(user_name,user_val,opp_name,opp_val)

    if user_val > opp_val:
        print("You've smashed the goblin to bits!")
        roll_again = input("(enter)")
        print("")
        status = "1 win"
else:
    pass
opp_name = "a goblin"
losscon(user_name,user_val,opp_name,opp_val)
roll_again = "n"

if status == "1 win":
    item_roll = random.randint(1,100)
    if item_roll > common:
        print("You notice a small vial next to your fallen opponent.")
        print("It's a Vial of Polish!")
        polish = input("Use, or discard the polish? (u/d): ")
        print("")
        if polish == "u":
            polish = 2
            print("")
            print("You are now using a Polished Wooden Die!")
            print("Max: 8")
            print("Min: 3")
            print("With great power, comes great responsibility.")
            print("")
            roll_again = input("(enter)")
            print("")
        else:
            print("You drop the vial and it shatters on a rock...")
            print("")
            pass
    else:
        pass    
else:
    pass

print("After the excitement with the goblin, you decide to rest and regain your strength.")
story = input("Once your heart finally calms down, you continue your journey. (enter)")
print("")
print("You walk for a few hours and find a lightly trodden dirt path.")
story = input("Do you follow it? (y/n): ")
if story == "y":
    print("You follow the path as it winds through the trees; ahead you begin to see a clearing.")
    print("As you draw nearer to the clearing, the moonlight hits your face and you make out what appears to be a wall of large hedges.")
    roll_again = input("(Enter)")
    print("After walking along the wall, you find an entrance to a maze!")
    s_var = input("Would you like to make an attempt at solving the maze? (y/n): ")
    print("")
    if s_var == "y":
        i_var = random.randint(1,100)
        if i_var > uncommon:
            roll_again = "y"
            print("While walking through the maze, you notice a faint light being emitted around the corner.")
            print("You slowly aproach the corner, preparing yourserlf for whatever awaits you.")
            s_var = input("(enter)")
        else:
            print("You walk around the maze for a while, but end up at a different entrance.")
            print("Feeling a little defeated, you begin to walk away from the maze and towards another dirt path.")
            roll_again = "n"
            pass
    else:
        pass    
else:
    pass

# Level 2: The Minotaur
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    print("")
    print("A mintaur roars to greet you, and throws his die your way!")
    print("Without a second thought, you hurl your die back at him.")

    polished_wood_die = random.randint(3,(6 + polish))
    wood_die = random.randint(3,6)

    user_val = polished_wood_die
    opp_name = "The Minotaur"
    opp_val = wood_die 
        
    fight(user_name,user_val,opp_name,opp_val)  
    
    if user_val > opp_val:
        print("You absolutely obliterated that one!")
        print("")
        roll_again = input("(enter)")
        print("")
else:
    pass
losscon(user_name,user_val,opp_name,opp_val)
roll_again  = "y"

if roll_again == "y":
    print("End.")
else:
    pass

# Level 3: Gargoyle

# Level 4: Teferi, Time Twister

# Final level: Blue-Eyes White Dragon # Not knowing what awaits you beyond, you continue boldly forward.