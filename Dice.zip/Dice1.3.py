import random
polish = 0
item_roll = 0

# Item Rarities
common = 10
uncommon = 25
rare = 50
mythic = 75
unique = 90

x = "intro"
roll_again = "y"
user_name = "nothing"
die_type = "Wood Die"

# Exits the game if the user's value is less than the opponents'
def losscon(user,userval,opponent,oppval):
    if userval < oppval:   
        print("")    
        print("%s, you've been defeated by %s." % (user,opponent))
        print("You lose.")
        print("")
    else:
        pass
    exit

# Runs through the fight sequence
def fight(user,userval,opponent,oppval):
    # 'Fight scene' message
    print("")
    print("You roll the dice at eachother...")
    print("...and the values are...")
    print("")
    # Accounting for a tie, defaulting to opponent1
    if userval - oppval == 0: 
        userval += 1
        pass
    else:
        # Fight output on screen
        print("%s: %d" % (user,userval))
        print("%s: %d" % (opponent,oppval))
        print("")    

if x == "intro":
    print("")
    print("")
    print("")
    print("")
    print("")
    print("Welcome adventurer!")
    print("")
    user_name = input("What is your name?: ")
    print("")
    print("You are currently using a %s." % die_type)
    print("Max: 6")
    print("Min: 3")
    print("")
    roll_again = input("Are you ready to start, %s? (y/n): " % user_name)
else:
    pass

# Level 1
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    # Defines 'wood_die' 'user_val' and 'opp_val' as random integers between the given parameters 
    # and defines the opponenets name
    wood_die = random.randint(3,6)
        
    user_val = wood_die
    opp_name = "Computer"
    opp_val = wood_die - 2
    
    # Calls the 'fight' function
    fight(user_name,user_val,opp_name,opp_val)

    # Checks if the user won
    if user_val > opp_val:
        print("You've smashed the computer to bits!")
        print("")
        roll_again = input("Move on to the next level? (y/n): ")
        print("")
else:
    pass

losscon(user_name,user_val,opp_name,opp_val)

item_roll = random.randint(1,100)
if item_roll > common:
    print("You notice a small vial next to your fallen opponent.")
    print("It's a Vial of Polish!")
    polish = input("Use, or discard the polish? (u/d): ")
    if polish == "u":
        polish = 1
        print("")
        print("You are now using a Polished Wooden Die!")
        print("Max: 7")
        print("Min: 3")
        print("")
        roll_again = input("Ready for the next level? (y/n): ")
        print("")
    else:
        pass
else:
    pass

# Level 2
if roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    
    polished_wood_die = random.randint(3,(6 + polish))

    user_val = polished_wood_die
    opp_name = "Computer 2.0"
    opp_val = wood_die - 1
        
    fight(user_name,user_val,opp_name,opp_val)  
    
    if user_val > opp_val:
        print("You absolutely obliterated that one!")
        print("")
        roll_again = input("Move on to the next level? (y/n): ")
        print("")
else:
    pass

losscon(user_name,user_val,opp_name,opp_val)

# Level 3: Gargoyle

# Level 4: Teferi, Time Twister

# Final level: Blue-Eyes White Dragon