import random
min = 1
max = 10

roll_again = "yes"

while roll_again == "yes" or roll_again == "y" or roll_again == "Yes":
    
    Computer = random.randint(min,max-5)
    Human = random.randint(min,max)
    
    print("Rolling the dice...")
    print("...and...")
    print("...the values are...")
    print("Computer: %d" % Computer)
    print("Human: %d" % Human)

    roll_again = input("Roll the dice again")
    print(roll_again)